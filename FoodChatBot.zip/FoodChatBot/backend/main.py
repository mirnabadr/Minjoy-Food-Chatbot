from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import db_helper
import generic_helper

# Initialize the FastAPI app
app = FastAPI()

# Dictionary to track in-progress orders
inprogress_orders = {}


@app.post("/")
async def handle_request(request: Request):
    """
    Main entry point to handle requests based on intent.
    """
    print("Handling request...")

    # Retrieve the JSON data from the request
    payload = await request.json()
    print("Payload received:", payload)

    # Extract necessary information from the payload
    try:
        intent = payload['queryResult']['intent']['displayName']
        parameters = payload['queryResult']['parameters']
        output_contexts = payload['queryResult']['outputContexts']
        session_id = generic_helper.extract_session_id(output_contexts[0]['name'])
    except KeyError as e:
        return JSONResponse(content={"fulfillmentText": f"Error parsing request: Missing key {e}"})

    # Extract intent and normalize
    intent = payload['queryResult']['intent']['displayName'].strip().lower()

    # Normalize keys in the intent_handler_dict for consistency
    intent_handler_dict = {
        'order.add - context: ongoing-order': add_to_order,
        'order.remove - context: ongoing-order': remove_from_order,
        'track.order - context: ongoing-tracking': track_order,  # Match the intent name in payload
        'order.complete- context: ongoing-order': complete_order,
    }

    # Check if the intent is supported
    if intent not in intent_handler_dict:
        return JSONResponse(content={"fulfillmentText": "Sorry, I can't handle this request."})

    # Call the appropriate handler function
    return intent_handler_dict[intent](parameters, session_id)




def remove_from_order(parameters: dict, session_id: str):
    """
    Removes items from an ongoing order.
    """
    # Check if the session ID exists in in-progress orders
    if session_id not in inprogress_orders:
        return JSONResponse(content={
            "fulfillmentText": "I'm having trouble finding your order. Sorry! Can you place a new order?"
        })

    # Get the current order for the session
    current_order = inprogress_orders[session_id]
    food_items = parameters.get("food-item", [])

    # If no food items are specified, handle the case
    if not food_items:
        return JSONResponse(content={
            "fulfillmentText": "You didn't specify any items to remove from your order."
        })

    removed_items = []
    no_such_items = []

    # Iterate over the food items to be removed
    for item in food_items:
        if item in current_order:
            removed_items.append(item)
            del current_order[item]
        else:
            no_such_items.append(item)

    # Construct the response text
    fulfillment_text = ""
    if removed_items:
        fulfillment_text += f"Removed {', '.join(removed_items)} from your order. "
    if no_such_items:
        fulfillment_text += f"Your current order does not include {', '.join(no_such_items)}. "

    # Check if the order is now empty
    if not current_order:
        fulfillment_text += "Your order is now empty!"
        del inprogress_orders[session_id]  # Clean up the session
    else:
        # Format the remaining order
        order_str = generic_helper.get_str_from_food_dict(current_order)
        fulfillment_text += f"Here is what is left in your order: {order_str}."

    return JSONResponse(content={"fulfillmentText": fulfillment_text})
    #parameters = {"food-item": ["pizza", "burger"]}
    # session_id = "session-1"
    #inprogress_orders = {"session-1": {"pizza": 2, "burger": 1, "soda": 1}}


def add_to_order(parameters: dict, session_id: str):
    """
    Handles adding food items to an ongoing order.
    """
    food_items = parameters.get("food-item", [])
    quantities = parameters.get("number", [])

    if len(food_items) != len(quantities):
        return JSONResponse(content={
            "fulfillmentText": "Sorry, I didn't understand. Can you please specify food items and quantities clearly?"
        })

    new_food_dict = dict(zip(food_items, quantities))
    if session_id in inprogress_orders:
        current_order = inprogress_orders[session_id]
        current_order.update(new_food_dict)
        inprogress_orders[session_id] = current_order
    else:
        inprogress_orders[session_id] = new_food_dict

    order_str = generic_helper.get_str_from_food_dict(inprogress_orders[session_id])
    return JSONResponse(content={"fulfillmentText": f"So far you have: {order_str}. Do you need anything else?"})


def complete_order(parameters: dict, session_id: str):
    """
    Completes an order, saving it to the database and providing an order ID.
    """
    if session_id not in inprogress_orders:
        return JSONResponse(content={
            "fulfillmentText": "I'm having trouble finding your order. Sorry! Can you place a new order, please?"
        })

    order = inprogress_orders[session_id]
    order_id = save_to_db(order)

    if order_id == -1:
        return JSONResponse(content={
            "fulfillmentText": "Sorry, I couldn't process your order due to a backend error. Please place a new order again."
        })

    order_total = db_helper.get_total_order_price(order_id)
    del inprogress_orders[session_id]
    return JSONResponse(content={
        "fulfillmentText": (
            f"Awesome! We've placed your order. Here is your order ID: #{order_id}. "
            f"Your order total is {order_total}, payable at the time of delivery!"
        )
    })


def save_to_db(order: dict) -> int:
    """
    Saves an order to the database and returns the generated order ID.
    """
    next_order_id = db_helper.get_next_order_id()
    for food_item, quantity in order.items():
        rcode = db_helper.insert_order_item(food_item, quantity, next_order_id)
        if rcode == -1:
            return -1
    db_helper.insert_order_tracking(next_order_id, "in progress")
    return next_order_id


def track_order(parameters: dict, session_id: str):
    """
    Handles tracking an order based on the order ID.
    """
    print("Inside track order")

    # Extract order ID and validate it
    order_id = parameters.get("order_id")
    if not order_id:
        return JSONResponse(content={"fulfillmentText": "Order ID is missing. Please provide a valid order ID."})

    try:
        order_id = int(order_id)
        order_status = db_helper.get_order_status(order_id)
    except ValueError:
        return JSONResponse(content={"fulfillmentText": "Invalid order ID. Please provide a numeric order ID."})

    # Check the order status
    if order_status:
        fulfillment_text = f"The order status for order ID {order_id} is: {order_status}."
    else:
        fulfillment_text = f"No order found with order ID {order_id}."

    return JSONResponse(content={"fulfillmentText": fulfillment_text})

